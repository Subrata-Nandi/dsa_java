/*
2. Write a recursive function to find the maximum and minimum number is the given list
that solves this using divide and conquer.
*/

package recursion_tree;
import java.util.*;

class mS {

	public void merge(int arr[], int low, int mid, int high) {
		int temp[] = new int[arr.length];
		int c=0;
		int left = low;
		int right = mid + 1;
		while(left <= mid && right <= high) {
			if(arr[left] <= arr[right]) {
				temp[c] = arr[left];
				c++;
				left++;
//				System.out.println("Hello1");
			}
			else {
				temp[c] = arr[right];
				c++;
				right++;
//				System.out.println("Hello2");
			}
		} 

		while(left <= mid) {
			temp[c] = arr[left];
			c++;
			left++;
//			System.out.println("Hello3");
		}

		while(right <= high) {
			temp[c] = arr[right];
			c++;
			right++;
//			System.out.println("Hello4");
		}

		for(int i=low;i<=high;i++) {
			arr[i] = temp[i-low];
		}
		
	}
	public void mergeSort(int arr[], int low, int high) {
		if(low >= high) 
			return;
		int mid = (low + high) / 2;
		mergeSort(arr, low, mid);
		mergeSort(arr, mid + 1, high);
		merge(arr, low, mid, high);
	}
	
	public void printArray(int arr[]) {
		for(int i=0;i<arr.length;i++) {
			System.out.print(arr[i] + " ");
		}
	}
	
	public void Pair(int arr[]) {
		int low = 0;
		mergeSort(arr, low, arr.length - 1);
		System.out.println("Minimum element is: " + arr[0]);
		System.out.println("Minimum element is: " + arr[arr.length-1]);
	}
}


public class MaxMin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		mS mg = new mS();
		int arr[] = {45,9,8,7,6,5,4,43,2,2,1,10};
		mg.Pair(arr);
	}

}

/*
Output

Minimum element is: 1
Minimum element is: 45

*/
